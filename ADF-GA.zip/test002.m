clc;
close all;
filename = 'this is your file...';

%% 
%
dat = readtable(char(filename),'ReadVariableNames',true);
var_type = table2array(dat(:,1:1));
var_length = table2array(dat(:,2:2));
var_name = table2array(dat(:,3:3));
N = 4; 
N_chrom = length(var_name);  
Pmut = 0.1;  
Pcross = 0.6; 
%%
%
chrom_range = get_range(var_type,var_length);  
chrom = zeros(N,N_chrom);
fitness = zeros(N, 1);
fitness_best = zeros(1,1);

chrom_best = zeros(1, N_chrom+1);   
%%

%%
%{
chrom = Initialize(N,N_chrom,chrom_range);  
firstchrom = chrom;
%}

%%
chrom = importdata('this is your file');  
firstchrom = chrom;

%%
org = 0.45;  
org1 = 0.35;
m = [38;38;38;38];
n = [20;20;20;20];
p = [9;15;9;15];
q = [2;2;2;2];

a = getfitness1(p,q,m,n,org,N);  %
fitness = CalFitness(a,N);  %
chrom_best = FindBest(chrom, fitness, N_chrom); 
fitness_best(1) = chrom_best(end); 
fitnessbest = chrom_best(end); 

%%
[chrom,newfitness] = chrom_prder(chrom,fitness,N_chrom,N);

sumfitness = 0;

temp_p = 0;  
for i = 1:N 
    fitness_sum(i) = 0;  
end
for i = 1:N  
   sumfitness = sumfitness + newfitness(i);
end
for i = 1:N
    temp_p = newfitness(i)/sumfitness;
    if i == 1
        fitness_sum(i) = temp_p;
    else
        fitness_sum(i) = fitness_sum(i-1) + temp_p;
    end
end
%% 
select_chrom = selectchrom(chrom,N,N_chrom,fitness_sum);

%%
cross_chrom = crosschrom_3(select_chrom,N_chrom,var_length,var_type,Pcross);

%%
mut_chrom = mutation(cross_chrom,N_chrom,var_length,Pmut);

%%
new_chrom = newchrom(mut_chrom,var_type,N_chrom);


