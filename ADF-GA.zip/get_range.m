function var_range = get_range( var_type,var_length )
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[num,num2] = size(var_type);
var_range = zeros(num,2); 
for i = 1:num
   if var_type(i) == 1  
       low = -power(2,var_length(i)-1);
       high = power(2,var_length(i)-1)-1;
   else if var_type(i) == 0  
       low = 0;
       high = power(2,var_length(i))-1;
       end
   end
   var_range(i,1) = low;
   var_range(i,2) = high;
end
end

