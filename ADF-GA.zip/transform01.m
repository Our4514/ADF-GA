function chrom_bindata= transform(var_now,var_length,N_chrom,var_type)
%   �˴���ʾ��ϸ˵��
chrom_bindata = cell(N_chrom,1);  for i = 1:N_chrom
   % var_new = zeros(1,var_length(i));
    if var_type(i) == 1 
        if var_now(1,i) >= 0  
            %{
            var_sym  = 0;   
            cen1 = dec2bin(var_now(1,i),var_length(i)-1);  
			cen2 = str2num(cen1); 
            var_new = [var_sym,cen2];
            %}
            cen = dec2bin(var_now(1,i),var_length(i));
            var_new = str2num(cen(:));
        else 
            %var_sym  = 1;   
            var_then(1,i) = abs(var_now(1,i));
            %var_now(1,i) = power(2,(var_length(i))) - var_now(1,i);
            cen1 = dec2bin(power(2,(var_length(i))) - var_then(1,i));  
            cen2 = str2num(cen1(:));
            var_new = cen2;
            %{
            var_now(1,i) = power(2,(var_length(i)-1)) - var_now(1,i); 
            cen1 = dec2bin(var_now(1,i),var_length(i));  
            cen2 = str2num(cen1(:)); 
            var_new = cen2;
            %}
        end
    else  
        cen1 = dec2bin(var_now(1,i),var_length(i));  
        var_new = str2num(cen1(:));
    end
    chrom_bindata{i} = var_new;
end    

end

