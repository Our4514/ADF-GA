clc;
close all;
range = zeros(64,2);
