function cross_chrom = crosschrom_4( select_chrom,N_chrom,var_length,var_type,Pcross )
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
%%
temp1 = cell(N_chrom,1);  
temp2 = cell(N_chrom,1);  
temp3 = cell(N_chrom,1);  
temp4 = cell(N_chrom,1);  

cross_chrom = cell(4,1);

cross_chrom_11 = transform(select_chrom(1,:),var_length,N_chrom,var_type);
rr1 = rand;  
if rr1 < Pcross  
    r1 = randi(4);  
    cross_chrom_21 = transform(select_chrom(r1,:),var_length,N_chrom,var_type); 
    if r1 ~= 1  
        for i = 1:N_chrom 
             length = var_length(i); 
             c1 = cross_chrom_11{i};  
             c2 = cross_chrom_21{i};  
             j = randi(length);  
             c1(j,:) = c2(j,:);  
             temp1{i} = c1;  
        end
    else   
        temp1 = cross_chrom_11;
    end 
else 
    temp1 = cross_chrom_11;
end
cross_chrom{1} = temp1;


cross_chrom_12 = transform(select_chrom(2,:),var_length,N_chrom,var_type);
rr2 = rand; 
if rr2 < Pcross  
    r2 = randi(4);  
    cross_chrom_22 = transform(select_chrom(r2,:),var_length,N_chrom,var_type); 
    if r2 ~= 2  
        for i = 1:N_chrom 
             length = var_length(i); 
             c1 = cross_chrom_12{i};  
             c2 = cross_chrom_22{i};  
             j = randi(length);  
             c1(j,:) = c2(j,:);  
             temp2{i} = c1; 
        end
    else   
        temp2 = cross_chrom_12;
    end   
else
    temp2 = cross_chrom_12;
end 
cross_chrom{2} = temp2;

cross_chrom_13 = transform(select_chrom(3,:),var_length,N_chrom,var_type);
rr3 = rand;  
if rr3 < Pcross  
    r3 = randi(4);  
    cross_chrom_23 = transform(select_chrom(r3,:),var_length,N_chrom,var_type); 
    if r3 ~= 3  
        for i = 1:N_chrom 
             length = var_length(i); 
             c1 = cross_chrom_13{i};  
             c2 = cross_chrom_23{i};  
             j = randi(length);  
             c1(j,:) = c2(j,:);  
             temp3{i} = c1;  
        end
    else   
        temp3 = cross_chrom_13;
    end  
else 
    temp3 = cross_chrom_13;
end 
cross_chrom{3} = temp3;

cross_chrom_14 = transform(select_chrom(4,:),var_length,N_chrom,var_type);
rr4 = rand;  
if rr4 < Pcross  %
    r4 = randi(4);  %
    cross_chrom_24 = transform(select_chrom(r4,:),var_length,N_chrom,var_type); % 
    if r4 ~= 4  % 
        for i = 1:N_chrom % 
             length = var_length(i); % 
             c1 = cross_chrom_14{i};  % 
             c2 = cross_chrom_24{i};  % 
             j = randi(length);  %
             c1(j,:) = c2(j,:);  %
             temp4{i} = c1;  % 
        end
    else   % 
        temp4 = cross_chrom_14;
    end  
else %
    temp4 = cross_chrom_14;
end 
cross_chrom{4} = temp4;
end

